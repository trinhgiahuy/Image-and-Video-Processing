function motionBlur
clc;
clear all;
close all;

% Read an image into the MATLAB workspace

I = imread('cameraman.tif');
figure; imshow(I); title('Original Image');

%% Create the PSF.
%
% h = fspecial('motion', len, theta) returns a filter to approximate, once
% convolved with an image, the linear motion of a camera by len pixels,
% with an angle of theta degrees in a counterclockwise direction. The
% filter becomes a vector for horizontal and vertical motions. The default
% len is 9 and the default theta is 0, which corresponds to a horizontal
% motion of nine pixels.

% To compute the filter coefficients, h, for 'motion':

%    1.      Construct an ideal line segment with the desired length and
%    angle, centered at the center coefficient of h.
%    2.      For each coefficient location (i,j), compute the nearest
%    distance between that location and the ideal line segment.
%    3.      h = max(1 - nearest_distance, 0);
%    4.      Normalize h:h = h/(sum(h(:))

temporalPSF = fspecial('motion', 3, 0);
temporalPSF3(1,1,1)=temporalPSF(1);
temporalPSF3(1,1,2)=temporalPSF(2);
temporalPSF3(1,1,3)=temporalPSF(3);

figure; imshow(temporalPSF, [], 'InitialMagnification', 'fit');
title('Original Temporal PSF');

% h = fspecial('average', hsize) returns an averaging filter h of size
% hsize. The argument hsize can be a vector specifying the number of rows
% and columns in h, or it can be a scalar, in which case h is a square
% matrix. The default value for hsize is [3 3].

spatialPSF = fspecial('average', [5, 5]);
spatialPSF5(:,:,1)=spatialPSF(:,:);

figure; imshow(spatialPSF, [], 'InitialMagnification', 'fit');
title('Original Spatial PSF');

Blurred(:,:,1) = spatialPSF5 * temporalPSF3(1,1,1);
Blurred(:,:,2) = spatialPSF5 * temporalPSF3(1,1,2);
Blurred(:,:,3) = spatialPSF5 * temporalPSF3(1,1,3);

% Blurred = imfilter(spatialPSF5,temporalPSF3,'circ','conv');
figure; imshow(Blurred); title('Blurred Image');
disp('Done');


